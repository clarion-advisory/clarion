import LoginReg from "@/app/components/LoginReg";

const Page = () => {
    return (
        <LoginReg />
    );
}

export default Page;