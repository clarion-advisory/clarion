'use client'

import LoginRegUser from "@/app/components/LoginRegUser";

const Page = () => {
    return (
        <LoginRegUser />
    );
}

export default Page;