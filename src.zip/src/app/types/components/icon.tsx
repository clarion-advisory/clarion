export interface icons {
    classname?: string,
    fill?: string,
    stroke?: string,
    size?: string | Number
}