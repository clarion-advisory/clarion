export interface compo {
    children?: React.ReactNode,
    className?: string
}